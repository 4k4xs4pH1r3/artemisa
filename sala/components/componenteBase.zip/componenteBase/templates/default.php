<?php defined('_EXEC') or die;
d($variables);
?>
<div class="panel widget">
    <div class="widget-header bg-primary"></div>
    <div class="widget-body text-center">
        <img alt="Profile Picture" class="widget-img img-circle img-border-light" src="<?php echo HTTP_SITE;?>/assets/img/av2.png">
        <h4 class="mar-no"><?php echo $test; ?></h4>
        <p class="text-muted mar-btm">Administrator</p>

        <div class="pad-ver">
                <button class="btn btn-primary">Follow</button>
                <button class="btn btn-success">Message</button>
        </div>
    </div>
</div>