<?php
/**
 * @author Andres Alberto Ariza <arizaandres@unbosque.edu.co>
 * @copyright Dirección de Tecnología Universidad el Bosque
 * @package model
 */
defined('_EXEC') or die;
class ComponenteBase{
    /**
     * @type adodb Object
     * @access private
     */
    private $db;
    
    public function ComponenteBase($db) {
        $this->db = $db;
    }
    
    public function getVariables($variables){
        $array = array();
        
        $array["test"] = "contenido variable test";
        
        //d($array);
        return $array;
    }
}
